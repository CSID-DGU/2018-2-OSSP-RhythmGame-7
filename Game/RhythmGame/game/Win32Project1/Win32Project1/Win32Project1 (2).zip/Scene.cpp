#include "Scene.h"


Scene::Scene()
{

}

Scene::~Scene()
{

}

void Scene::Init()
{
}

void Scene::Deinit()
{
}

void Scene::Update(int deltaTime)
{
}

void Scene::Render()
{
}



void Scene::KeyUp(unsigned int keyCode)
{
}

void Scene::KeyDown(unsigned int keyCode)
{
}
