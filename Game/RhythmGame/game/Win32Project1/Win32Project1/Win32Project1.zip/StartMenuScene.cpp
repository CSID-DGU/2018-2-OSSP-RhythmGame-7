#include <stdio.h>
#include "GameSystem.h"
#include "Sprite.h"
#include "SceneManager.h"

#include "StartMenuScene.h"
#include "Font.h"


StartMenuScene::StartMenuScene()
{
}

StartMenuScene::~StartMenuScene()
{
}

void StartMenuScene::Init()
{
	_test = new Font("arialbd.ttf", 50);
	_test1 = new Font("arialbd.ttf", 50);
	_test2 = new Font("arialbd.ttf", 50);
	_test3 = new Font("arialbd.ttf", 50);
	

	_backgroundSprite = new Sprite("backgroundspr", true);
	_backgroundSprite->SetPosition(GameSystem::GetInstance()->GetWindowWidth() / 2,
		GameSystem::GetInstance()->GetWindowHeight() / 2);

	_waitTick = 3 * 1000;
	_updateTick = 0;
}

void StartMenuScene::Deinit()
{

	delete _backgroundSprite;
}

void StartMenuScene::Update(int deltaTime)
{

	char text[256];
	sprintf(text, "START");
	_test->SetText(text, 450, 300);

	char text1[256];
	sprintf(text1, "OPTION");
	_test1->SetText(text1, 450, 350);

	char text2[256];
	sprintf(text2, "HELP");
	_test2->SetText(text2, 450, 400);

	char text3[256];
	sprintf(text3, "QUIT GAME");
	_test3->SetText(text3, 450, 450);

	_backgroundSprite->Update(deltaTime);

	if (_waitTick < _updateTick)
	{
		SceneManager::GetInstance()->ChangeScene(eScene::SCENE_TITLE);
	}
	_updateTick += deltaTime;
}

void StartMenuScene::Render()
{
	_backgroundSprite->Render();
	_test->Render();
	_test1->Render();
	_test2->Render();
	_test3->Render();
}

void StartMenuScene::KeyUp(unsigned int keyCode)
{
	int i = 1;

	switch (keyCode)
	{
	case SDLK_SPACE:
		SceneManager::GetInstance()->ChangeScene(eScene::SCENE_TITLE);
		break;
	case SDLK_UP:
		
		break;
	default:
		break;
	}
}

void StartMenuScene::KeyDown(unsigned int keyCode)
{
}
